import UIKit

/// MARK: Задание к уроку 1:

//1) Прочитать доку apple касаемо этого урока
//
//2) В вики найти значение слова константа и переменная  и понять разницу этих значений
//
//3) Создать характеристики студента, через константы или переменные, чтобы это было имя, фамилия, рост, вес, возраст.
//Вывести красиво имя студента и фамилию в консоль, используя команду print

let name = "Andrei"
let lastName = "Fokin"
let height = 185
let weight = 100
let age = 37

print("My name is \(name) \(lastName), I'm \(age) years old. My weight is \(weight) and height is \(height)")
