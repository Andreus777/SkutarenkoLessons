import UIKit

//    . Выполните задание 1 урока о базовых операторах: /skuter04
//    только вместо forced unwrapping и optional binding используйте оператор ??

let a = "27"
let b = "1dd4"
let c = "45"
let d = "23t"
let e = "123"

let resultA = Int(a) ?? 0
let resultB = Int(b) ?? 0
let resultC = Int(c) ?? 0
let resultD = Int(d) ?? 0
let resultE = Int(e) ?? 0

let commonResult = resultA + resultB + resultC + resultD + resultE

print("\(resultA) + \(resultB) + \(resultC) + \(resultD) + \(resultE) = \(commonResult)")


//    Когда посчитаете сумму, то представьте свое выражение в виде строки
//    Например: 5 + nil + 2 + 3 + nil = 10
//
//    но в первом случае используйте интерполяцию строк, а во втором конкатенацию
//
//    2. Поиграйтесь с юникодом и создайте строку из 5 самых классных по вашему мнению символов,
//    можно использовать составные символы. Посчитайте длину строки методом SWIFT и Obj-C
//
//    3. Создайте строку английский алфавит, все буквы малые от a до z
//    задайте константу - один из символов этого алфавита
//    Используя цикл for определите под каким индексов в строке находится этот символ




let alphabet = "abcdefghijklmnopqrstuvwxyz"

let myLetter: Character = "t"

var index = 1
for letter in alphabet{
    if letter == myLetter{
        print(index)
    } else {
        index += 1
    }
}
