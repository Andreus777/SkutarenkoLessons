import UIKit

//1. Выведите в консоль минимальные и максимальные значения базовых типов, не ленитесь :)

//2. Создайте 3 константы с типами Int, Float и Double

//Создайте другие 3 константы, тех же типов: Int, Float и Double,
//при чем каждая из них это сумма первых трех, но со своим типом

//3. Сравните Int результат суммы с Double и выведите отчет в консоль


print(Int.max)
print(Int.min)
print(UInt.max)
print(UInt.min)
print(UInt32.max)
print(UInt16.min)


let a = 7
let b = 6.3
let c: Float = 7.34

let sumInt = a + Int(b) + Int(c)

let sumDouble = Double(a) + b + Double(c)

let sumFloat = Float(a) + Float(b) + c

Double(sumInt) > sumDouble ? print("Сумма Int больше суммы Double на \(sumDouble - Double(sumInt))"): print("Сумма Double меньше суммы Int на \(Double(sumInt) - sumDouble)")
