import UIKit

//    1. Создать структуру “Описание файла” содержащую свойства:
//    - путь к файлу
//    - имя файла
//    - максимальный размер файла на диске
//    - путь к папке, содержащей этот файл
//    - тип файла (скрытый или нет)
//    - содержимое файла (можно просто симулировать контент)
//
//    Главная задача - это использовать правильные свойства там, где нужно, чтобы не пришлось хранить одни и те же данные в разных местах и т.д. и т.п.

struct FileDescription{
    var url: String
    var fileName: String
    static var maxFileWeight: Int = 150
    static var folderURL: String = "MyCompFiles"
    var isHidden: Bool
    var informationInFile: String
}

let file = FileDescription(url: "http:\\www.open.by", fileName: "Text.txt", isHidden: false, informationInFile: "some text")


print(FileDescription.maxFileWeight)
print(FileDescription.folderURL)
print(file.isHidden)



//    2. Создайте энум, который будет представлять некую цветовую гамму. Этот энум должен быть типа Int и как raw значение должен иметь соответствующее 3 байтное представление цвета. Добавьте в этот энум 3 свойства типа: количество цветов в гамме, начальный цвет и конечный цвет.

enum Gamma: Int {
    case red = 0xFF0000
    case blue = 0_0_255
    case green = 0_255_0
    
    static var coloursInGamma: Int{
        return 3
    }
}
print(Gamma.red.rawValue)


//    3. Создайте класс человек, который будет содержать имя, фамилию, возраст, рост и вес. Добавьте несколько свойств непосредственно этому классу чтобы контролировать:
//    - минимальный и максимальный возраст каждого объекта
//    - минимальную и максимальную длину имени и фамилии
//    - минимально возможный рост и вес
//    - самое интересное, создайте свойство, которое будет содержать количество созданных объектов этого класса

class Human {
    
    static var count: Int = 0
    static var minAge = 16
    static var maxAge = 80
    static var minLenhgtName = 4
    static var maxLenhgtName = 20
    static var minWeight = 40
    static var minHeight = 150
    
    var name: String {
        didSet{
            if name.count < Human.minLenhgtName || name.count > Human.maxLenhgtName {
                name = oldValue
            }
        }
    }
    var lastName: String {
        didSet{
            if lastName.count < Human.minLenhgtName || lastName.count > Human.maxLenhgtName {
                lastName = oldValue
            }
        }
    }
    var age: Int {
        didSet{
            if age < Human.minAge || age > Human.maxAge {
                age = oldValue
            }
        }
    }
    var height: Int {
        didSet{
            if height < Human.minHeight {
                height = oldValue
            }
        }
    }
    var weight:Int {
        didSet{
            if weight < Human.minHeight {
                weight = oldValue
            }
        }
    }
    
    init(name: String, lastName: String, age: Int, height: Int, weight: Int){
        self.name = name
        self.lastName = lastName
        self.age = age
        self.height = height
        self.weight = weight
        Human.count += 1
    }
}

let human1 = Human(name: "Andrew", lastName: "Fokin", age: 37, height: 185, weight: 103)
let human2 = Human(name: "Vova", lastName: "Prokhorov", age: 36, height: 182, weight: 91)
let human3 = Human(name: "Andrew", lastName: "Alehno", age: 37, height: 176, weight: 78)

Human.count

print(human1.age)
print(human1.name)
print(human1.lastName)
print(human1.weight)
print(human1.height)

human1.age = 10
human1.name = "ad"
human1.lastName = "asflgjhsofghosidjf;asdmf;asdfgpasidfjgj"
human1.weight = 35
human1.height = 150

print(human1.age)
print(human1.name)
print(human1.lastName)
print(human1.weight)
print(human1.height)
