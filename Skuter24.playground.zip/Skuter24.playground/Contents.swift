import UIKit

extension Int {
   
    var isNegative: Bool {
        if self < 0 {
            return true
        }
        return false
    }
    
    var isPositive: Bool {
        return self > 0 ? true : false
    }
    
    var isZero: Bool {
        return self == 0 ? true : false
    }
    
    var numberOfSymbols: Int {
        let string = String(self)
        return string.count
    }
    
    subscript(number: Int) -> Int{
        var a = 1
        for _ in 0..<number {
            a *= 10
        }
        return (self / a ) % 10
    }
    
}

let a = 7
let b = -11
let c = 0
let d = 45689
let e = 98574833749

a.isNegative
b.isNegative

a.isPositive
b.isNegative

a.isZero
c.isZero

d.numberOfSymbols
e.numberOfSymbols


12345809[0]


