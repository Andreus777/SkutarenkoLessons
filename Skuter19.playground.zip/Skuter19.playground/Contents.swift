import UIKit


func myFunc (_ array: [Int]) -> [Int]?{
    
    guard array.count <= 2 else {return nil}
    
    var newArray = [Int]()
    
    guard let first = array.first, let last = array.last else {return nil}
    
    newArray.append(contentsOf: [first, last])
    
    return newArray
}
    


