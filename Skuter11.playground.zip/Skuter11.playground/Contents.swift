import UIKit

//1. Написать функцию, которая ничего не возвращает и принимает только один клоужер, который ничего не принимает и ничего не возвращает . Функция должна просто посчитать от 1 до 10 в цикле и после этого вызвать клоужер. Добавьте println в каждый виток цикла и в клоужер и проследите за очередностью выполнения команд.

func simpleClosure(closure: () -> ()){
    for i in 0...5 {
        print(i)
    }
    closure()
}

simpleClosure {print("use closure")}

//2. Используя метод массивов sorted, отсортируйте массив интов по возрастанию и убыванию. Пример показан в методичке.

let array = [1, 6, 2, 4, 8, 11, 54, 0, 2, 4, 6, 22, 1, 8]

let array1 = array.sorted(by: >)
let array2 = array.sorted { (number1, number2) in
    return number1 < number2
}

let array3 = array.max(by: <)
let array4 = array.map { value in
    value + 2
}
let array5 = array.map{$0*$0}
let array6 = array.reduce(0, +)


//3. Напишите функцию, которая принимает массив интов и клоужер и возвращает инт. Клоужер должен принимать 2 инта (один опшинал) и возвращать да или нет. В самой функции создайте опшинал переменную. Вы должны пройтись в цикле по массиву интов и сравнивать элементы с переменной используя клоужер. Если клоужер возвращает да, то вы записываете значение массива в переменную. в конце функции возвращайте переменную.

func testFunc(array: [Int], closure: (Int, Int?) -> Bool) -> Int {
    var value: Int?
    for item in array {
        if closure(item, value){
            value = item
        }
    }
    return value ?? 0
}

//используя этот метод и этот клоужер найдите максимальный и минимальный элементы массива.

let max = testFunc(array: array) {
    guard let a = $1 else {return true}
    return a < $0
}

print(max)

let min = testFunc(array: array) { (number1, number2) in
    guard let number2 = number2 else {return true}
    return number1 < number2
}
print(min)


//4. Создайте произвольную строку. Преобразуйте ее в массив букв. Используя метод массивов sorted отсортируйте строку так, чтобы вначале шли гласные в алфавитном порядке, потом согласные, потом цифры, а потом символы

func priority(string: String)-> Int{
    switch string{
    case "a","e","i","o","u","y": return 0
    case "a"..."z": return 1
    case "0"..."9": return 2
    default: return 3
    }
}

let string = "fas9dg3asbgas5zf6b3596WERGscv!!<>>SdfAWT@eghww!#!#$fmk"
var charArray:[String] = []

for char in string{
    charArray.append(String(char).lowercased())
}

let sortedCharArray = charArray.sorted{
    switch(priority(string: $0), priority(string: $1)){
    case let (x, y) where x < y: return true
    case let (x, y) where x > y: return false
    default: return $0.lowercased() <= $1.lowercased()
        
    }
}
print(sortedCharArray)


//5. Проделайте задание №3 но для нахождения минимальной и максимальной буквы из массива букв (соответственно скалярному значению)

func testFunc2(string: String, closure: (Character, Character?) -> Bool) -> Character {
    var value: Character?
    for item in string {
        if closure(item, value){
            value = item
        }
    }
    return value ?? " "
}

let maxLetter = testFunc2(string: string) { (number1, number2) in
    guard let number2 = number2 else {return true}
    return number1 > number2
}

print("Max letter is \(maxLetter)")

let minLetter = testFunc2(string: string) { (number1, number2) in
    guard let number2 = number2 else {return true}
    return number1 < number2
}
print("Mix letter is \(minLetter)")
