import UIKit
import Foundation

//    1. Создать энум с шахматными фигруами (король, ферзь и т.д.). Каждая фигура должна иметь цвет белый либо черный (надеюсь намек понят), а так же букву и цифру для позиции. Создайте пару фигур с расположением на доске, так, чтобы черному королю был мат :) Поместите эти фигуры в массив фигур

enum ChessFigure {
    
    case Король(colour: Colour, position: Position)
    case Ферзь(colour: Colour, position: Position)
    case Слон(colour: Colour, position: Position)
    case Конь
    case Ладья(colour: Colour, position: Position)
    case Пешка(colour: Colour, position: Position)
    
    enum Colour {
        case white, black
    }
    
    enum Position {
        case a1, b1, c1, d1, e1, f1, g1, h1
        case a2, b2, c2, d2, e2, f2, g2, h2
        case a3, b3, c3, d3, e3, f3, g3, h3
        case a4, b4, c4, d4, e4, f4, g4, h4
        case a5, b5, c5, d5, e5, f5, g5, h5
        case a6, b6, c6, d6, e6, f6, g6, h6
        case a7, b7, c7, d7, e7, f7, g7, h7
        case a8, b8, c8, d8, e8, f8, g8, h8
    }
}

//MARK: Линейный мат

let king = ChessFigure.Король(colour: .white, position: .a3)
let queen = ChessFigure.Ферзь(colour: .black, position: .a7)
let castle = ChessFigure.Ладья(colour: .black, position: .b5)

var figures:[ChessFigure] = [king, queen, castle]


//    2. Сделайте так, чтобы энумовские значения имели rawValue типа String. Каждому типу фигуры установите соответствующее английское название. Создайте функцию, которая выводит в консоль (текстово, без юникода) название фигуры, цвет и расположение. Используя эту функцию распечатайте все фигуры в массиве.

enum Figure {
   
    case Король(name: Name, colour: Colour2, letter: Letter2, row: Row)
    case Ферзь(name: Name, colour: Colour2, letter: Letter2, row: Row)
    case Слон(name: Name, colour: Colour2, letter: Letter2, row: Row)
    case Конь(name: Name, colour: Colour2, letter: Letter2, row: Row)
    case Ладья(name: Name, colour: Colour2, letter: Letter2, row: Row)
    case Пешка(name: Name, colour: Colour2, letter: Letter2, row: Row)

    enum Name: String {
        
        case Король = "King"
        case Ферзь = "Queen"
        case Слон = "Bishop"
        case Конь = "Horse"
        case Ладья = "Castle"
        case Пешка = "Pawn"
    }
    
    enum Colour2: String {
        case white = "white", black = "black"
    }
    
    enum Letter2: String {
        case a = "A", b = "B", c = "C", d = "D", e = "E", f = "F", g = "G", h = "H"
    }
    
    enum Row: Int {
        case One = 1, Two, Three, Four, Five, Six, Seven, Eight
    }
}

let king2 = Figure.Король(name: .Король, colour: .white, letter: .a, row: .Three)
let queen2 = Figure.Ферзь(name: .Ферзь, colour: .black, letter: .a, row: .Seven)
let castle2 = Figure.Ладья(name: .Ладья, colour: .black, letter: .b, row: .Five)

let chess = [king2, queen2, castle2]

func printFigure(_ figure: Figure) {
    switch figure{
    case .Король(let name, let colour, let letter, let row):
        print("\(name.rawValue) \(colour.rawValue) on \(letter.rawValue)\(row.rawValue)")
        print ("♚")
    case .Ферзь(let name, let colour, let letter, let row):
        print("\(name.rawValue) \(colour.rawValue) on \(letter.rawValue)\(row.rawValue)")
        colour == .white ? print("♕") : print("♛")
    case .Слон(let name, let colour, let letter, let row):
        print("\(name.rawValue) \(colour.rawValue) on \(letter.rawValue)\(row.rawValue)")
    case .Конь(let name, let colour, let letter, let row):
        print("\(name.rawValue) \(colour.rawValue) on \(letter.rawValue)\(row.rawValue)")
    case .Ладья(let name, let colour, let letter, let row):
        print("\(name.rawValue) \(colour.rawValue) on \(letter.rawValue)\(row.rawValue)")
    case .Пешка(let name, let colour, let letter, let row):
        print("\(name.rawValue) \(colour.rawValue) on \(letter.rawValue)\(row.rawValue)")
    }
}

for figure in chess {
    printFigure(figure)
}

//    3. Используя красивые юникодовые представления шахматных фигур, выведите в консоли вашу доску. Если клетка не содержит фигуры, то используйте белую или черную клетку. Это должна быть отдельная функция, которая распечатывает доску с фигурами (принимает массив фигур и ничего не возвращает)

func chessGame (figures: [Figure]){
        print("""
  A B C D E F G  H
1⬜️⬛️⬜️⬛️⬜️⬛️⬜️⬛️
2⬛️⬜️⬛️⬜️⬛️⬜️⬛️⬜️
3 ♕⬛️⬜️⬛️⬜️⬛️⬜️⬛️
4⬛️⬜️⬛️⬜️⬛️⬜️⬛️⬜️
5⬜️⬛️⬜️⬛️⬜️⬛️⬜️⬛️
6⬛️⬜️⬛️⬜️⬛️⬜️⬛️⬜️
7⬜️⬛️⬜️⬛️⬜️⬛️⬜️⬛️
8⬛️⬜️⬛️⬜️⬛️⬜️⬛️⬜️
  A B C D E F G  H
""")
    }


chessGame(figures: chess)

//    4. Создайте функцию, которая будет принимать шахматную фигуру и тюпл новой позиции. Эта функция должна передвигать фигуру на новую позицию, причем перемещение должно быть легальным: нельзя передвинуть фигуру за пределы поля и нельзя двигать фигуры так, как нельзя их двигать в реальных шахматах (для мегамонстров программирования). Вызовите эту функцию для нескольких фигур и распечатайте поле снова.

