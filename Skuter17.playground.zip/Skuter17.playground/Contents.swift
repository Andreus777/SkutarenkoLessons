import UIKit

//    1. Создайте тип шахматная доска.
//    2. Добавьте сабскрипт, который выдает цвет клетки по координате клетки (буква и цифра).
//    3. Если юзер ошибся координатами - выдавайте ошибку

struct ChessBoard {
   
   static let dict = ["a": 1,"b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8 ]
    
   static subscript (column: String, row: Int) -> String? {
       
       if 1...8 ~= row && 1...8 ~= dict[column.lowercased()] ?? 0 {
            
           if row % 2 == dict[column.lowercased()]! % 2 {
                return "black"
            } else {
                return "white"
            }
        } else {
            return "Please check input Data"
        }
        
    }
}
    
ChessBoard["g", 8]
ChessBoard["A", 5]
ChessBoard["l", 5]
    


//  Крестики нолики (Средний уровень)

//    1. Создать тип, представляющий собой поле для игры в крестики нолики
//    На каждой клетке может быть только одно из значений: Пусто, Крестик, Нолик
//    Добавьте возможность красиво распечатывать поле

//    2. Добавьте сабскрипт, который устанавливает значение клетки по ряду и столбцу,
//    причем вы должны следить за тем, чтобы программа не падала если будет введен не существующий ряд или столбец.

//    3. Также следите за тем, чтобы нельзя было устанавливать крестик либо нолик туда, где они уже что-то есть. Добавьте метод очистки поля.

//    4. Если хотите, добавте алгоритм, который вычислит победителя

struct Field {
    var rows = 3
    var columns = 3
    var grid: [String]
    
    init (rows: Int, columns: Int) {
        self.rows = rows
        self.columns = columns
        grid = Array(repeating: "⬜️", count: rows * columns)
    }
    
    subscript(row: Int, column: Int) -> String? {
        get{
            if 1...3 ~= row && 1...3 ~= column {
                return grid[((row-1)*column) + column-1]
            } else {
                return nil
            }
        }
        set{
            if 1...3 ~= row && 1...3 ~= column && grid[((row-1)*column) + column-1] == "⬜️"{
                grid[((row-1)*column) + column-1] = newValue ?? "⬜️"
            } else {
                print("This place is already bisy")
            }
        }
    }
    
}
    
    enum Cross: String {
        case zero = "〇"
        case cross = "╳"
        case empty = "⬜️"
    }
    
    

var playField = Field(rows: 3, columns: 3)
playField.grid

playField[3,3] = "〇"
playField[2,3] = "╳"
playField[1,3] = "〇"

playField.grid
playField[1,3] = "╳"

playField.grid





//    Морской бой (Тяжелый уровень)
//
//    1. Создайте тип корабль, который будет представлять собой прямоугольник. В нем может быть внутренняя одномерная система координат (попахивает сабскриптом). Корабль должен принимать выстрелы по локальным координатам и вычислять когда он убит
//
//    2. Создайте двумерное поле, на котором будут располагаться корабли врага. Стреляйте по полю и подбейте вражеский четырех трубник :)
//
//    3. Сделайте для приличия пару выстрелов мимо, красивенько все выводите на экран :)
