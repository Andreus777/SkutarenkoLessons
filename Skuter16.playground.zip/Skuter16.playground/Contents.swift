import UIKit

//1. Создайте тип Комната. У комнаты есть размеры W на H. И создайте тип Персонаж. У негоесть координата в комнате X и Y. Реализуйте функцию, которая красивенько текстом будет показывать положение персонажа в комнате

struct Room {
    var width: Int
    var height: Int
    
    var hero: Hero
    
    var box: Box
    
    var target: Target
    
    func showHero(){
        print("The hero is on x: \(hero.position.x) y: \(hero.position.y) on the room with size of \(width) on \(height) and there is a box in the room on x: \(box.position.x) y: \(box.position.y). You need to move the box to the target on x: \(target.position.x) y: \(target.position.y) ")
    }
    
    
}




struct Position {
    var x: Int
    var y: Int
    mutating func moving (by newX: Int, newY: Int){
        self.x += newX
        self.y += newY
    }
}

struct Hero {
    
    var position: Position
    
    enum Move{
        case up
        case down
        case left
        case right
    }
    
    mutating func walk(direction: Move){
        switch direction {
        case .up: position.moving(by: 1, newY: 0)
        case .down: position.moving(by: -1, newY: 0)
        case .left: position.moving(by: 0, newY: -1)
        case .right: position.moving(by: 0, newY: 1)
        }
    }
}

struct Box {
    var position: Position
    
}

struct Target{
    var position: Position
}

var myHero = Hero(position: Position(x: 1, y: 1))
var myBox = Box(position: Position(x: 2, y: 2))
var myTarget = Target(position: Position(x: 4, y: 6))
var myRoom = Room(width: 10, height: 10, hero: myHero, box: myBox, target: myTarget)

myRoom.showHero()

print(myHero.position)
print(myBox.position)
print(myTarget.position)

myHero.walk(direction: .right)
myBox.position.moving(by: 2, newY: 2)

print(myHero.position)
print(myBox.position)

myHero.walk(direction: .right)
print(myHero.position)






//2. Персонажу добавьте метод идти, который принимает энумчик лево, право, верх, вниз
//Этот метод должен передвигать персонажа. Реализуйте правило что персонаж не должен покинуть пределы комнаты. Подвигайте персонажа и покажите это графически

//3. Создать тип Ящик. У ящика также есть координата в комнате X и Y. Ящик также не может покидать пределы комнаты и ящик также должен быть распечатан вместе с персонажем в функции печати.

//4. Теперь самое интересное, персонаж может двигать ящик, если он стоит на том месте, куда персонаж хочет попасть. Главное что ни один объект не может покинуть пределы комнаты. Подвигайте ящик :)

//5. Добавьте точку в комнате, куда надо ящик передвинуть и двигайте :)

//Для суперменов: можете добавить массив ящиков и можете сделать консольное приложение


