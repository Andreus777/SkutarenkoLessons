import UIKit


var a: Character = 64

var b: Character = "a"
