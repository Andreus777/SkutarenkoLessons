import UIKit

//1. создать массив "дни в месяцах"
//12 элементов содержащих количество дней в соответствующем месяце
//используя цикл for и этот массив
//- выведите количество дней в каждом месяце (без имен месяцев)

let dayInMonthArray = [30, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

for days in dayInMonthArray {
    print("\(days) days in month")
}

//- используйте еще один массив с именами месяцев чтобы вывести название месяца + количество дней

let monthArray = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December",]

for day in 0..<dayInMonthArray.count {
        print("\(dayInMonthArray[day]) days in \(monthArray[day])")
    }

//- сделайте тоже самое, но используя массив тюплов с параметрами (имя месяца, кол-во дней)

let tupleArray = [("January", 30),("February", 28),("March", 31),("April", 30),("May", 31), ("June", 30),("July", 31),("August", 31),("September", 30),("October", 31),("November", 30),("December", 31)]


for (month, days) in tupleArray {
    print("In \(month) where are \(days) days")
}

//- сделайте тоже самое, только выводите дни в обратном порядке (порядок в массиве не меняется)

for (month, days) in tupleArray.reversed() {
    print("In \(month) where are \(days) days")
}

//- для произвольно выбранной даты (месяц и день) посчитайте количество дней до этой даты от начала года

let randomMonth = 10
let randomDate = 18
var sum = 0

for days in 0...randomMonth-1 {
    sum = sum + dayInMonthArray[days]
}
print (sum + randomDate)

//2. Сделайте первое задание к уроку номер 4 используя массивы
//(создайте массив опшинал интов и посчитайте сумму)

let stringToNumbers = ["23", "1w", "18", "123m", "33", "993"]

var result = 0
for value in stringToNumbers{
    if let myValue = Int(value){
        result += myValue
    }
}
print(result)

//- в одном случае используйте optional binding
//- в другом forced unwrapping
//- а в третьем оператор ??

let opt = [1, nil, 3, nil, 7]
