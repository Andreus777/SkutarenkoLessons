import UIKit
import Foundation

//1. Создайте пару функций с короткими именами, которые возвращают строку с классным символом или символами. Например heart() возвращает сердце и т.п. Вызовите все эти функции внутри принта для вывода строки этих символов путем конкатенации.

func printHeart () -> String {
    return "💝"
}
func printBeer() -> String{
    return "🍺"
}

print("\(printHeart()) + \(printBeer()) = love!")


//2. Опять шахматные клетки. Реализовать функцию, которая принимает букву и символ и возвращает строку “белая” или “черная”. Строку потом распечатайте в консоль

func chessBoard (letter: String, number: Int) -> String {
   
    let lettersToNumber = ["A": 1, "B": 2,"C": 3,"D": 4,"E": 5,"F": 6,"G": 7,"H": 8 ]
    
    return number % 2 == lettersToNumber[letter.uppercased()]! % 2 ? "white" : "black"
}

chessBoard(letter: "e", number: 7)

//3. Создайте функцию, которая принимает массив, а возвращает массив в обратном порядке. Можете создать еще одну, которая принимает последовательность и возвращает массив в обратном порядке. Чтобы не дублировать код, сделайте так, чтобы функция с последовательностью вызывала первую.

func sortedArray(array: [Any]) -> [Any] {
    return array.reversed()
}

print(sortedArray(array: ["2", "1", "0"]))

//4. Разберитесь с inout самостоятельно и выполните задание номер 3 так, чтобы функция не возвращала перевернутый массив, но меняла элементы в существующем. Что будет если убрать inout?


func sortedInoutArray (array: inout [Int]){
    array = array + [6,7,9]
}

var ar = [3, 2, 1]

sortedInoutArray(array: &ar)

//5. Создайте функцию, которая принимает строку, убирает из нее все знаки препинания, делает все гласные большими буквами, согласные маленькими, а цифры меняет на соответствующие слова (9 -> nine и тд)

func correctString(text: String) -> String {
    var newString = ""
    let numbers = ["0": "Zero",
                   "1":" One",
                   "2": "Two",
                   "3": "Three",
                   "4": "Four",
                   "5": "Five",
                   "6": "Six",
                   "7": "Seven",
                   "8": "Eight",
                   "9": "Nine"]
    
    for char in text {
        switch String(char).lowercased() {
    case ".", ",", "!", "?", ":", "-", ">", "<":
            newString += " "
    case "a","e","i","o","u","y":
            newString += char.uppercased()
    case "1","2","3","4","5","6","7","8","9","0":
           newString += numbers[String(char)]!
    case " ":
            newString += " "
    default:
            newString += char.lowercased()
    }
 }
    return newString
}

print(correctString(text: " 11The function definition still 55 needs parent6heses after the function’s name, even though it doesn’t take any parameters. The function name is also followed by an empty pair of parentheses when the function is called.33"))
