import UIKit

//Сегодня будем строить свою небольшую социальную сеть.
//

//1. Сделать класс Человек, у этого класса будут проперти Папа, Мама, Братья, Сестры (всё опционально).
//Сделать примерно 30 человек, взять одного из них, поставить ему Папу/Маму. Папе и Маме поставить Пап/Мам/Братьев/Сестер. Получится большое дерево иерархии.
//Посчитать, сколько у этого человека двоюродных Братьев, троюродных Сестёр, Теть, Дядь, итд

//2. Все сестры, матери,... должны быть класса Женщина, Папы, братья,... класса Мужчины.
//У Мужчин сделать метод Двигать_диван, у Женщин Дать_указание (двигать_диван). Всё должно работать как и ранее.
//Всех этих людей положить в массив Семья, пройти по массиву посчитать количество Мужчин и Женщин, для каждого Мужчины вызвать метод Двигать_диван, для каждой женщины Дать_указание.

//3. Расширить класс человек, у него будет проперти Домашние_животные. Животные могут быть разные (попугаи, кошки, собаки...) их может быть несколько, может и не быть вообще.
//Раздать некоторым людям домашних животных. Пройти по всему массиву людей. Проверить каждого человека на наличие питомца, если такой есть - добавлять всех животных в массив животных. Посчитать сколько каких животных в этом массиве.
//Вся эта живность должна быть унаследована от класса Животные. У всех животных должен быть метод Издать_звук(крик) и у каждого дочернего класса этот метод переопределён на свой, т.е. каждое животное издаёт свой звук.
//Когда проходим по массиву животных, каждый представитель вида животных должен издать свой звук.


class Human {
    var father: Man?
    var mother: Woman?
    var sister: Woman?
    var brother: Man?
    var pet: Animal?
}

class Animal{
    func voice(){
        print("make sound")
    }
}

class Man {
    func moveSofa (){
        print("move sofa")
    }
}

class Woman{
    func washDishes (){
        print ("wash dishes")
    }
}

class Father: Man{
    var name = "Father Name"
}

class Mother: Woman{
    var name = "Mother name"
}

class Sister: Woman {
    var name = "Sister name"
}

class Brother: Man {
    var name = "Brother name"
}


var human1 = Human()
var human2 = Human()
var human3 = Human()
var human4 = Human()
var human5 = Human()
var human6 = Human()

human1.mother = Woman()
human1.father = Man()


human2.sister = Sister()
human2.sister?.washDishes()

human1.mother?.washDishes()
human1.mother
human1.father?.moveSofa()
human1.brother

human3 = human1

human6.sister = Sister()

///MARK:


class Earth {
    var country: Country? = Country()
}

class Country {
    var city: City? = City()
}

class City {
    var street: Street? = Street()
}

class Street {
    var house: House? = House()
}

class House {
    let houseNumber = Int.random(in: 0...100)
}

let myEarth = Earth()


var myHouseNumber = myEarth.country?.city?.street?.house?.houseNumber
print(myHouseNumber ?? "SHIT!")

if let myHouseNumber2 = myEarth.country?.city?.street?.house?.houseNumber {
    print(myHouseNumber2)} else {
        print("no value")
    }


if let country = myEarth.country {
    if let city = country.city {
        if let street = city.street {
            if let house = street.house {
                house.houseNumber
            }
        }
    }
}
