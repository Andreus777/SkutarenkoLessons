import UIKit

////    1. Создайте структуру студент. Добавьте свойства: имя, фамилия, год рождения, средний бал. Создайте несколько экземпляров этой структуры и заполните их данными. Положите их всех в массив (журнал).

struct Student1 {

    var name: String
    var lastName: String
    var birtgYear: Int
    var avMark: Double
}
//
var student1 = Student1(name: "Andrey", lastName: "Fokin", birtgYear: 1984, avMark: 4.8)
var student2 = Student1(name: "Andrey", lastName: "Alehno", birtgYear: 1984, avMark: 4.7)
var student3 = Student1(name: "Vova", lastName: "Prokhorov", birtgYear: 1985, avMark: 4.6)
var student4 = Student1(name: "Tanya", lastName: "Romanchenko", birtgYear: 1981, avMark: 5.0)

var classMagazine = [student1, student2, student3]
classMagazine.append(student4)



////    2. Напишите функцию, которая принимает массив студентов и выводит в консоль данные каждого. Перед выводом каждого студента добавляйте порядковый номер в “журнале”, начиная с 1.
//
func studentInfo (from students: [Student1]) {
    var number = 0
    for student in students {
        number += 1
        print("\(number). Name: \(student.name) \(student.lastName), birth: \(student.birtgYear), avarage mark: \(student.avMark) ")
    }
}

studentInfo(from: classMagazine)
print("--------Sorted by mark------------")

//    3. С помощью функции sorted отсортируйте массив по среднему баллу, по убыванию и распечатайте “журнал”.

let sortedByMarkClass = classMagazine.sorted { a, b in
    return a.avMark > b.avMark
}

studentInfo(from: sortedByMarkClass)

////    4. Отсортируйте теперь массив по фамилии (по возрастанию), причем если фамилии одинаковые, а вы сделайте так чтобы такое произошло, то сравниваются по имени. Распечатайте “журнал”.
print("--------Sorted by name------------")

let sortedByName = classMagazine.sorted { name1, name2 in
    return name1.name == name2.name ? name1.lastName < name2.lastName : name1.name < name2.name
}

studentInfo(from: sortedByName)

////    5. Создайте переменную и присвойте ей ваш существующий массив. Измените в нем данные всех студентов. Изменится ли первый массив? Распечатайте оба массива.
//
print("--------Value type test------------")

var currentArray = classMagazine

studentInfo(from: classMagazine)
print("--")
studentInfo(from: currentArray)

student1.name = "PISUN"

print("after changing-")
studentInfo(from: classMagazine)
print("--")
studentInfo(from: currentArray)

////    6. Теперь проделайте все тоже самое, но не для структуры Студент, а для класса. Какой результат в 5м задании? Что изменилось и почему?


class Student {

    var name: String
    var lastName: String
    var birtgYear: Int
    var avMark: Double

    init(name: String, lastName: String, birtgYear: Int, avMark: Double){
        self.name = name
        self.lastName = lastName
        self.birtgYear = birtgYear
        self.avMark = avMark
    }
}


var student11 = Student(name: "Andrey", lastName: "Fokin", birtgYear: 1984, avMark: 4.8)
var student22 = Student(name: "Andrey", lastName: "Alehno", birtgYear: 1984, avMark: 4.7)
var student33 = Student(name: "Vova", lastName: "Prokhorov", birtgYear: 1985, avMark: 4.6)
var student44 = Student(name: "Tanya", lastName: "Romanchenko", birtgYear: 1981, avMark: 5.0)

func studentInfo (from students: [Student]) {
    var number = 0
    for student in students {
        number += 1
        print("\(number). Name: \(student.name) \(student.lastName), birth: \(student.birtgYear), avarage mark: \(student.avMark) ")
    }
}

var classStudentArray = [student11, student22, student33, student44]
var newArray = classStudentArray

studentInfo(from: classStudentArray)
print("--------Value type test------------")
studentInfo(from: newArray)

student11.name = "PISUN"

print("----------------------------------")
studentInfo(from: classStudentArray)
print("--------After type test------------")
studentInfo(from: newArray)





//    007. Уровень супермен
//    Выполните задание шахмат из урока по энумам используя структуры либо классы


struct Chess {
    var figure: Figure
    var colour: Color
    var position: Position
    
    enum Figure: String {
        case King = "♔", Queen = "♕", Bishop = "♝", Horse = "♘", Castle = "♖", Pawn = "♙"
    }
    
    enum Color {
        case white, black
    }
    
    enum Position {
        case a1, b1, c1, d1, e1, f1, g1, h1
        case a2, b2, c2, d2, e2, f2, g2, h2
        case a3, b3, c3, d3, e3, f3, g3, h3
        case a4, b4, c4, d4, e4, f4, g4, h4
        case a5, b5, c5, d5, e5, f5, g5, h5
        case a6, b6, c6, d6, e6, f6, g6, h6
        case a7, b7, c7, d7, e7, f7, g7, h7
        case a8, b8, c8, d8, e8, f8, g8, h8
    }
}

let myFigure = Chess(figure: .King, colour: .white, position: .a4)
print("\(myFigure.colour) \(myFigure.figure.rawValue) \(myFigure.position)")
