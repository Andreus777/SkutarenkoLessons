import UIKit

//1. Посчитать количество секунд от начала года до вашего дня рождения. Игнорируйте високосный год и переходы на летнее и зимнее время. Но если хотите - не игнорируйте :)

let months = (January: 31, February: 28, March: 31, April: 30, May: 31, June: 30, July: 31, August: 31, September: 30, October: 31, November: 30, December: 31)
let secondInDay = 60 * 60 * 24
let myBirthday = 18
let secodsFromMyBirthday = (months.January + months.February + months.March + months.April + months.May + months.June + months.July + months.August + months.September + myBirthday) * secondInDay
print("Quantity of seconds from the beggining of the year till my birthday is \(secodsFromMyBirthday)")

//2. Посчитайте в каком квартале вы родились

let myMonthBirth = 10

switch myMonthBirth {
case 1...3:
    print("I was born in first quarter")
case 4...6:
    print("I was born in second quarter")
case 7...9:
    print("I was born in third quarter")
default:
    print("I was born in fourth quarter")
    
}

//3. Создайте пять переменных типа Инт и добавьте их в выражения со сложением, вычитанием, умножением и делением. В этих выражениях каждая из переменных должна иметь при себе унарный постфиксный или префиксный оператор. Переменные могут повторяться. Убедитесь что ваши вычисления в голове или на бумаге совпадают с ответом. Обратите внимание на приоритет операций

var a = 1
var b = 2
var c = 3
var d = 4
var e = 5

//let result = +a - b + -c - +d + e
//print(result)

//4. Шахматная доска 8х8. Каждое значение в диапазоне 1…8. При заданных двух значениях по вертикали и горизонтали определите цвет поля. Если хотите усложнить задачу, то вместо цифр на горизонтальной оси используйте буквы a,b,c,d,e,f,g,h

let horizontalValue: Int = 6
let verticalValue: Int = 5

verticalValue % 2 == 0 && horizontalValue % 2 == 1 ? print("клетка белая") : print ("клетка черная")
    


