import UIKit

//1. Создайте дикшинари как журнал студентов, где имя и фамилия студента это ключ, а оценка за контрольную значение. Некоторым студентам повысьте оценки - они пересдали. Потом добавьте парочку студентов, так как их только что перевели к вам в группу. А потом несколько удалите, так как они от вас ушли :(

var classMagazine = ["Фокин Андрей": 5,
                     "Алехно Андрей": 4,
                     "Чикун Андрей": 4,
                     "Шилко Александр": 5,
                     "Прохоров Владимир": 4]

print(classMagazine)

classMagazine["Алехно Андрей"] = 5
classMagazine["Чикун Андрей"] = 5
print(classMagazine)

classMagazine["Русецкий Александр"] = 4
classMagazine["Ястремский Алексей"] = 5
print(classMagazine)

classMagazine.removeValue(forKey: "Фокин Андрей")
classMagazine.removeValue(forKey: "Шилко Александр")
print(classMagazine)

//После всех этих перетрубаций посчитайте общий бал группы и средний бал

var sum = 0
for value in classMagazine.values{
    sum += value
}

print(sum)

print(Double(sum)/Double(classMagazine.count))



//2. Создать дикшинари дни в месяцах, где месяц это ключ, а количество дней - значение.
//В цикле выведите ключ-значение попарно, причем один раз выведите через тюплы, а другой раз пройдитесь по массиву ключей и для каждого из них доставайте значения.
var yearDictionary = ["January": 31,
                      "February": 28,
                      "March": 31,
                      "April": 30,
                      "May": 31,
                      "June": 30,
                      "July": 31,
                      "August": 31,
                      "September": 30,
                      "October": 31,
                      "November": 30,
                      "December": 31]

//for (key, value) in yearDictionary {
//    print ("\(key) with \(value)")
//}

for key in yearDictionary.keys {
    print("\(key) \(yearDictionary[key]!)")
}

//3. Создать дикшинари , в которой ключ это адрес шахматной клетки (пример: a5, b3, g8), а значение это Bool. Если у клетки белый цвет, то значение true, а если черный - false. Выведите дикшинари в печать и убедитесь что все правильно.
//
//Рекомендация: постарайтесь все сделать используя вложенный цикл (объяснение в уроке).
 
let letterArray = ["a","b","c","d","e","f","g"]
let numberArray = [1, 2, 3, 4, 5, 6, 7 ,8]
var chessDictionary: [String: Bool] = [:]

var index = 0
for letter in letterArray {
    index += 1
    for number in numberArray {
        chessDictionary[letter + String(number)] = (number % 2 == index % 2) ? false : true
    }
}

print(chessDictionary)
