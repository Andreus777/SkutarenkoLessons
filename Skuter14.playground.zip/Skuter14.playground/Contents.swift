import UIKit
import Foundation

//1. Самостоятельно повторить проделанное в уроке

struct Student {
    
    var firstName: String{
        willSet{
            print (newValue + "!")
        }
        didSet{
            print(oldValue + "!!")
        }
    }
    
    var lastName: String
    var fullName: String{
        get{
            return "\(firstName) \(lastName)"
        }
        
        set{
            print("full name wants to be changed to \(newValue)")
        }
    }
    
}

var student = Student(firstName: "Andrew", lastName: "Fokin")


print(student.fullName)
student.firstName = "Vova"
print(student.fullName)

student.firstName = "PISUN"
student.fullName = "Pisun Pisunov"


//2. Добавить студенту property «Дата рождения» (пусть это будет еще одна структура, содержащая день, месяц, год) и два computed property: первое — вычисляющее его возраст, второе — вычисляющее, сколько лет он учился (считать, что он учился в школе с 6 лет, если студенту меньше 6 лет — возвращать 0)


struct Birth {
    var year: Int
    var month: Int
    var day: Int
    
    var age: Int {
        return 2021 - year
    }
    
    var study: Int{
        age <= 6 ? 0 : age - 6
    }
}


struct Student1 {
    
    var firstName: String{
        willSet{
            print (newValue + "!")
        }
        didSet{
            print(oldValue + "!!")
        }
    }
    
    var lastName: String
    var fullName: String{
        get{
            return "\(firstName) \(lastName)"
        }
        
        set{
            print("full name wants to be changed to \(newValue)")
        }
    }
    var birthDay: Birth
}

var student1 = Student1(firstName: "Andrei", lastName: "Alehno", birthDay: Birth(year: 1984, month: 10, day: 18))

print(student1.fullName)
print(student1.birthDay.age)
print(student1.birthDay.study)

student1.birthDay.year = 2020
print(student1.birthDay.age)
print(student1.birthDay.study)

//3. Создать структуру «Отрезок», содержащую две внутренние структуры «Точки». Структуру «Точка» создать самостоятельно, несмотря на уже имеющуюся в Swift’е. Таким образом, структура «Отрезок» содержит две структуры «Точки» — точки A и B (stored properties). Добавить два computed properties: « середина отрезка» и «длина» (считать математическими функциями)

struct Section {
    
    struct PointA {
        var (x, y): (Double, Double)
    }
    
    struct PointB {
        var (x1, y1): (Double, Double)
    }
    
    var pointA: PointA
    var pointB: PointB
    
    var lenghtSection: Double {
        get{
            sqrt((pow(pointA.x - pointB.x1, 2)) + (pow(pointA.y - pointB.y1, 2)))
        }
        
        set{
            pointB.x1 = pointA.x + newValue*(pointB.x1 - pointA.x)/lenghtSection
            pointB.y1 = pointA.y + newValue*(pointB.y1 - pointA.y)/lenghtSection
        }
    }
    
    var middleSection: (Double, Double){
        get{
        let x3 = (pointA.x + pointB.x1)/2
        let y3 = (pointA.y + pointB.y1)/2
        
        return (x3, y3)
    }
        set{
            let deltaX = newValue.0 - middleSection.0
            let deltaY = newValue.1 - middleSection.1
            
            pointA.x += deltaX
            pointB.x1 += deltaX
            
            pointA.y += deltaY
            pointB.y1 += deltaY
        }
    }
}

var section = Section(pointA: Section.PointA(x: 2, y: 3), pointB: Section.PointB(x1: 6, y1: 9))

print(section.pointA)
print(section.pointB)
print(section.lenghtSection)
print(section.middleSection)

//4. При изменении середины отрезка должно меняться положение точек A и B. При изменении длины, меняется положение точки B



section.middleSection = (6, 8)
print(section.pointA)
print(section.pointB)

section.lenghtSection = 14
print(section.pointB)
