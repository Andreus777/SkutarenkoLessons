import UIKit

//1. Создать пять строковых констант
//Одни константы это только цифры, другие содержат еще и буквы

let a = "27"
let b = "1dd4"
let c = "45"
let d = "23t"
let e = "123"

//Найти сумму всех этих констант приведя их к Int
//(Используйте и optional binding и forced unwrapping)

var sum = 0

if let aInt = Int(a){
    sum += aInt
}

if let bInt = Int(b){
    sum += bInt
}
if let cInt = Int(c){
    sum += cInt
}
if let dInt = Int(d){
    sum += dInt
}
if let eInt = Int(e){
    sum += eInt
}

print(sum)


//2. С сервера к нам приходит тюпл с тремя параметрами:
//statusCode, message, errorMessage (число, строка и строка)
//в этом тюпле statusCode всегда содержит данные, но сама строка приходит только в одном поле
//если statusCode от 200 до 300 исключительно, то выводите message,
//в противном случает выводите errorMessage
//После этого проделайте тоже самое только без участия statusCode

var myRequest: (statusCode: Int, message: String?, errorMessage: String?)

myRequest = (200, "normal", "error")

if myRequest.statusCode > 200 {
    print (myRequest.message!)
} else {
    print (myRequest.errorMessage!)
}

//3. Создайте 5 тюплов с тремя параметрами:
//имя, номер машины, оценка за контрольную
//при создании этих тюплов не должно быть никаких данных
//после создания каждому студенту установите имя
//некоторым установите номер машины
//некоторым установите результат контрольной
//выведите в консоль:
//
//- имена студента
//- есть ли у него машина
//- если да, то какой номер
//- был ли на контрольной
//- если да, то какая оценка


var student1: (name: String?, license: Int?, mark: Int?)

student1.name = "Andrew"
student1.mark = 5

if let studentName = student1.name, let mark = student1.mark {
    print("Student name is \(studentName) and his mark is \(mark)")
}


