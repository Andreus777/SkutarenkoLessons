import UIKit

//1. Создать тюпл с тремя параметрами:
//
//- максимальное количество отжиманий
//- максимальное количество подтягиваний
//- максимальное количество приседаний
//
//Заполните его своими достижениями :)
//
//Распечатайте его через print()
//
//2. Также сделайте три отдельных вывода в консоль для каждого параметра
//
//При том одни значения доставайте по индексу, а другие по параметру
//
//3. Создайте такой же тюпл для другого человека (супруги или друга)
//
//с такими же параметрами, но с другими значениями
//
//Используйте промежуточную переменную чтобы поменять соответствующие значения
//
//первого тюпла на значения второго
//
//4. Создайте третий тюпл с теми же параметрами, но значения это разница
//
//между соответствующими значениями первого и второго тюплов
//
//Результат выведите в консоль


var myTraining = (maxPushUps: 20, maxPullUps: 10, maxSquast: 50)

print("\(myTraining.maxPushUps), \(myTraining.maxPullUps), \(myTraining.maxSquast)")

myTraining.0
myTraining.maxPullUps
myTraining.2

var myWifeTraining = (maxPushUps: 3, maxPullUps: 1, maxSquast: 20)

var tupleForChange: (Int, Int, Int)

tupleForChange = myWifeTraining
myWifeTraining = myTraining
myTraining = tupleForChange

print(myTraining)
print(myWifeTraining)

var differenceTuple = (myTraining.maxPushUps - myWifeTraining.maxPushUps, myTraining.maxPullUps - myWifeTraining.maxPullUps, myTraining.maxSquast - myWifeTraining.maxSquast)

print(differenceTuple)



