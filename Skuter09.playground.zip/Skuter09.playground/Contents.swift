import UIKit

//1. Создать строку произвольного текста, минимум 200 символов. Используя цикл и оператор свитч посчитать количество гласных, согласных, цифр и символов.

let customString = "Hello, my name is Andrew and I'm 37 years old! I try to learn Swift :). I study every fuckin day!! And i still love it! I really want to sleep, but ia can't, because i must finish my homework! Good luck to me!)"

customString.count

var numbers = 0
var vowel = 0
var consonant = 0
var digit = 0

for char in customString{
    switch char{
    case "a", "e", "i", "o", "u", "y":
        vowel += 1
        continue
    case "1", "2", "3", "4", "5", "6", "7", "8", "9", "0":
        numbers += 1
        continue
    case "!", ")", ",", ":", ".", "'":
        digit += 1
        continue
    case " ":
        continue
    default:
        consonant += 1
    }
}

print("\(numbers), \(vowel), \(consonant), \(digit)")




//2. Создайте свитч который принимает возраст человека и выводит описание жизненного этапа

let age = 37

switch age {
case 0...15:
    print("child")
case 16...25:
    print("young man")
case 26...35:
    print("man")
case 36...50:
    print("cool man")
default: print("old man")
}

//3. У вас есть имя отчество и фамилия студента (русские буквы). Имя начинается с А или О, то обращайтесь к студенту по имени, если же нет, то если у него отчество начинается на В или Д, то обращайтесь к нему по имени и отчеству, если же опять нет, то в случае если фамилия начинается с Е или З, то обращайтесь к нему только по фамилии. В противном случае обращайтесь к нему по полному имени.

let person = ("Андрей", "Васильевич", "Фокин")

switch person{
    case (let name, _, _) where name.hasPrefix("А") || name.hasPrefix("О"):
    print ("Hello \(name)")
case (_, let secondName, _) where secondName.hasPrefix("В") || secondName.hasPrefix("Д"):
    print("Hello \(person.0) \(secondName)")
case (_, _, let lastName) where lastName.hasPrefix("Е") || lastName.hasPrefix("З"):
    print("Hello \(lastName)")
default:
    print("Hello \(person.0) \(person.1) \(person.2)")
}

//4. Представьте что вы играете в морской бои и у вас осталось некоторое количество кораблей на поле 10Х10 (можно буквы и цифры, а можно только цифры). Вы должны создать свитч, который примет тюпл с координатой и выдаст один из вариантов: мимо, ранил, убил.

let coordinates = (x:2,y:5)


switch coordinates {
case (2,5):
    print("Get it!")
case (3,6):
    print("Missing")
default:
    print("end game")
}
