import UIKit

//1. У нас есть базовый клас "Артист" и у него есть имя и фамилия. И есть метод "Выступление". У каждого артиста должно быть свое выступление: танцор танцует, певец поет и тд. А для художника, что бы вы не пытались ставить, пусть он ставит что-то свое (пусть меняет имя на свое артистическое). Когда вызываем метод "выступление" показать в консоле имя и фамилию артиста и собственно само выступление.
//Полиморфизм используем для артистов. Положить их всех в массив, пройтись по нему и вызвать их метод "выступление"

class Artist {
    var name: String
    var lastName: String
    func show() -> String{
        "\(name) \(lastName) Make some show"
    }
    
    init(name: String, lastName: String){
        self.name = name
        self.lastName = lastName
    }
}

class Dancer: Artist {
    override func show() -> String {
        super.show() + " with dance"
    }
}

class Singer: Artist {
    override func show() -> String {
        super.show() + " with sing song"
    }
}

class Painter: Artist {
    
    override init(name: String, lastName: String) {
        super.init(name: "TRULALA", lastName: "ULALAL")
    }
//   override var name: String {
//        get{
//            return super.name
//        }
//
//        set{
//            super.name = "Picasso"
//        }
//    }
    
    override func show() -> String {
        super.show() + " with paint pictures"
    }
}


var artist = Artist(name: "Charley", lastName: "Chaplin")
var dancer = Dancer(name: "Michael", lastName: "Jackson")
var singer = Singer(name: "Frank", lastName: "Sinatra")
var painter = Painter(name: "Leonardo", lastName: "Davinci")


let artistArray = [artist, dancer, singer, painter]

for person in artistArray {
    print(person.show())
}

//2. Создать базовый клас "транспортное средство" и добавить три разных проперти: скорость, вместимость и стоимость одной перевозки (computed). Создайте несколько дочерних класов и переопределите их компютед проперти у всех. Создайте класс самолет, корабль, вертолет, машина и у каждого по одному объекту. В компютед пропертис каждого класса напишите свои значения скорости, вместимости, стоимости перевозки. + у вас должен быть свой метод который считает сколько уйдет денег и времени что бы перевести из пункта А в пункт В определенное количество людей с использованимем наших транспортных средств. Вывести в кольсоль результат (как быстро сможем перевести, стоимость, количество перевозок).
//Используем полиморфизм

class Vehicle {
    var speed: Int {return 0}
    var capacity: Int {return 0}
    var ticketCost: Int {return 0}
    
    func travelPrice (distance: Double) -> String {
        return "Price of travel is \(capacity*ticketCost) with \(distance/Double(speed)) ours"
    }
}

class Fly: Vehicle {
    override var speed: Int {return 300}
    override var capacity: Int {return 1000}
    override var ticketCost: Int {return 250}
}

class Sheep: Vehicle {
    override var speed: Int {return 100}
    override var capacity: Int {return 5000}
    override var ticketCost: Int {return 400}
}

class Helicopter: Vehicle {
    override var speed: Int {return 200}
    override var capacity: Int {return 7}
    override var ticketCost: Int {return 180}
}

class Car: Vehicle {
    override var speed: Int {return 90}
    override var capacity: Int {return 5}
    override var ticketCost: Int {return 10}
}

let vehicle = Vehicle()
let airplane = Fly()
let sheep = Sheep()
let helicopter = Helicopter()
let car = Car()

let vehicleArray = [vehicle, airplane, sheep, helicopter, car]

for transport in vehicleArray{
    print(transport.travelPrice(distance: 2000))
}




//3. Есть 5 классов: люди, крокодилы, обезьяны, собаки, жирафы. (в этом задании вы будете создавать не дочерние классы, а родительские и ваша задача создать родительский таким образом, что бы группировать эти 5).
//- Создайте по пару объектов каждого класса.
//- Посчитайте присмыкающихся (создайте масив, поместите туда присмыкающихся и скажите сколько в нем объектов)
//- Сколько четвероногих?
//- Сколько здесь животных?
//- Сколько живых существ?


class LivingBeing{}
    class Human: LivingBeing{}
    class Animal: LivingBeing{}
        class Monkey:Animal{}
        class FourLegs: Animal{}
            class Dog:FourLegs{}
            class Giraffe: FourLegs{}
            class Lizard: FourLegs{}
                    class Crocodale: Lizard{}


let human1 = Human()
let human2 = Human()

let crocodale1 = Crocodale()
let crocodale2 = Crocodale()

let monkey1 = Monkey()
let monkey2 = Monkey()

let dog1 = Dog()
let dog2 = Dog()

let giraffe1 = Giraffe()
let giraffe2 = Giraffe()

let array = [human1, human2, crocodale1, crocodale2, monkey1, monkey2, dog1, dog2, giraffe1, giraffe2]

var livingBeing = 0
var myAnimal = 0
var fourLegs = 0
var lizard = 0


for animal in array {
    if animal is LivingBeing {
        livingBeing += 1
    }
    if animal is FourLegs {
        fourLegs += 1
    }
    if animal is Animal {
        myAnimal += 1
    }
    if animal is Lizard {
        lizard += 1
    }
}
    print(livingBeing)
    print(myAnimal)
    print(fourLegs)
    print(lizard)
